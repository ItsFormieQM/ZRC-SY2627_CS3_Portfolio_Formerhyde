Task related to the learning resource 2
ACTIVITY 1
—-------------
Allotted Time: 10 minutes
Grading: Non-graded, and submission is NOT required.
Instruction:
For each situation below, decide whether the attribute should be public, protected, or private,
then write the correct Python statement to declare the attribute inside the __init__()
constructor method. Do these on your notebook.
1. A GameCharacter class has a username that can be displayed and accessed by anyone. - Answer: Public
def __init__(self):
    self.username = ""
    
2. A BankAccount class has a balance that should NOT be accessed directly outside the
class. - Answer: Private
def __init__(self):
    self.username = "Kris"
3. A Vehicle class has an engineCode that should only be accessed within the class and its
subclasses. - Answer: Private
def __init__(self):
    self.username = "Kris"

4. A Student class has a schoolName that is safe for everyone to view and modify. - Answer: Private
def __init__(self):
    self.username = "Kris"
5. A VotingSystem class has a voterID that must be hidden for security reasons. - Answer: Private
The teacher may ask some students to share their answers for the discussion. - Answer: Private

ACTIVITY 2
—------------
Allotted Time: 14 minutes
Grading: Non-graded but submission required.
Submission: Upload your file to the Khub submission bin.
File Name: Follow the file name format provided by your teacher.
Instruction:
Watch the video, then recreate the Rectangle class code demonstrated in the video, with
width and height as private members. Pay close attention to how the @property decorator is
used, how getter and setter methods are named, and how these methods work like regular
variables.
Ensure that your code runs without any errors.
Then, answer this reflection question in your notebook.
➢ How does using @property make your code easier to read compared to using
traditional get_ and set_ methods?
- Answer: @property makes it easy to set variables because it doesn't involve using functions that can potentially break other people modifying the class's to add their own functions. 
Examples:
Instead of using instance_handle.set_price(666), you can use instance_handle.price = 666 and it can optionally check for a negative value if added.
Be prepared to share and explain your code/answer during class discussion if called upon.