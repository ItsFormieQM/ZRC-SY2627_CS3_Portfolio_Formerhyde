class Rectangle:
    def __init__(self,width,height):
        self.__width = width
        self.__height = height
    @property
    def width(self):
        return f"{self.__width:.2f}"
    @property
    def height(self):
        return f"{self.__height:.2f}"
    @width.setter
    def width(self,width):
        if width <= -1:
            print("Value must not be negative!")
            return
        self.__width = width

    @height.setter
    def height(self,width):
        if width <= -1:
            print("Value must not be negative!")
            return
        self.__height = self.height
    @width.deleter
    def width(self):
        del self.__width
        print(f"Width has been deleted")
    @height.deleter
    def height(self):
        del self.__height
        print(f"Height has been deleted")

rectangle = Rectangle(3,4)
rectangle.width = 7
rectangle.height = -666

del rectangle.width
del rectangle.height


    