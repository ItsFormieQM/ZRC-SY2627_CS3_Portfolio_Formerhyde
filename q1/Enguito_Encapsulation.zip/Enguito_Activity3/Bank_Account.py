
class BankAccount:
    def __init__(self,account_number,balance):
        self.__account_number = account_number
        if balance <= -1:
            print("Warning. Balance must not be negative!")
        self.__balance = balance
        print("Account 1")
        print(f"Account Number: {self.__account_number}")
        print(f"Balance: {self.__balance}")

    def set_account_number(self,account_number):
        print(f"Account Number set to {account_number}")
        self.__account_number = account_number
        print(f"Account Number: {self.__account_number}")
    def set_balance(self,balance):
        print(f"Update balance to {balance}")
        if balance <= -1:
            print("The balance must not be a negative number.")
            return
        self.__balance = balance
    def get_account_number(self):
        return f"Account Number: {self.__account_number}"

    def get_balance(self):
        return f"Balance is: {self.__balance:.2f}"

# // demonstration ig?
a1 = BankAccount(12345,1000)
a1.set_balance(-100)
a1.get_balance()
a1.set_account_number(666)
print(a1.get_balance())